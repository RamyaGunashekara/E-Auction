SET NAMES utf8mb4;

INSERT INTO `buyer` (`id`, `address`, `amount`, `city`, `email`, `first_name`, `last_name`, `phone`, `pin`, `product_id`, `state`) VALUES
('03d4bdd4-6126-41b3-9371-3499b4ea9c0d',	'251, 6364 Nibh Avenue	',	4500,	'Melbourne',	'Albany@hotmail.edu',	'Albany',	'Albert',	932741422,	675915,	'6b3f1577-cf87-4d03-bf82-770b5fbd5660',	'Melbourne'),
('40148b3e-0c2e-49fa-9501-7d5cd15f4c64',	'97 Border Drive',	120,	'Melbourne',	'natoque.penatibus@icloud.edu',	'Myles',	'Stout',	77741877,	675915,	'd4e605d7-c1e5-4234-84ff-95e2ff620dd1',	'Melbourne'),
('61849997-fb50-4190-9e63-dd9e24d8925f',	'350 Morris Road Hopewell',	100,	'Melbourne',	'mauris.id@hotmail.edu',	'Zane',	'Frye',	977741422,	675915,	'840d42bb-18c6-4678-b23a-c0ea2c230fea',	'Melbourne'),
('6ab9bc87-4b82-411f-8b6f-11d9d48d792b',	'2962 Burning Memory Lane',	30,	'Melbourne',	'GertrudeRRector@armyspy.com',	'Gertrude',	'Rector',	1234579,	675915,	'2ec41f02-e6a5-4341-b997-ff72d9281bf1',	'Melbourne'),
('78ff399c-c055-45bd-9fc4-f628056ddf39',	'21 Marloo Street',	2100,	'Melbourne',	'bob.fruey@gmail.com',	'Bob',	'Frye',	932741422,	675915,	'fc1ce675-aec2-4a43-929a-dad4c903a032',	'Melbourne'),
('8c7822bd-4940-465b-8b3c-fbdc230b8d98',	'29 Cherokee Road Bradford',	120,	'Melbourne',	'natoque.penatibus@icloud.edu',	'Myles',	'Stout',	77741877,	675915,	'ddf488c8-883f-46d9-80bb-47f8fe899a9e',	'Melbourne'),
('92479aee-82b6-4e5b-ab9b-32312585c4dd',	'55 Hart Street Green creek',	4000,	'Melbourne',	'mike.id@hotmail.edu',	'Mike',	'Frye',	932741422,	675915,	'6b3f1577-cf87-4d03-bf82-770b5fbd5660',	'Melbourne'),
('a9f78154-d5fe-4839-8d78-4c3cd8df752f',	'66 Chatsworth Drive',	40,	'Melbourne',	'Rosalina.Nowlin@hotmail.edu',	'Rosalina',	'Nowlin',	932741422,	675915,	'2ec41f02-e6a5-4341-b997-ff72d9281bf1',	'Melbourne'),
('b41b7cca-5990-4a56-addb-f783ab3219b9',	'52 Benny Street Nientreet',	67,	'Melbourne',	'ultrices@hotmail.net',	'Preston',	'Golden',	577741422,	675915,	'840d42bb-18c6-4678-b23a-c0ea2c230fea',	'Melbourne'),
('de86b9c2-9533-4e93-b6bd-7ed890fe2a0d',	'48 Wynyard Street',	45,	'Melbourne',	'lorem.vitae@google.ca',	'Jesse',	'Lingham',	77741877,	675915,	'840d42bb-18c6-4678-b23a-c0ea2c230fea',	'Melbourne'),
('eccd3bc5-cc3e-4a64-b1fb-78bdeff893aa',	'4296 Spadafore Drive',	25,	'Melbourne',	'GabrielleDLanglinais@teleworm.us',	'Gabrielle',	'Langlinais',	817822704,	675915,	'2ec41f02-e6a5-4341-b997-ff72d9281bf1',	'Melbourne'),
('f1a96d63-f1a1-45ed-8995-4f290f1a18d4',	'2449 Scelerisque Road',	2000,	'Melbourne',	'mauris.id@hotmail.edu',	'Zane',	'Ocon',	977741422,	675915,	'fc1ce675-aec2-4a43-929a-dad4c903a032',	'Melbourne');
